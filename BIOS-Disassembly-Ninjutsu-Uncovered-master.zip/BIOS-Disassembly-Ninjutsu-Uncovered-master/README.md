# README

This project hosts PDF file of the BIOS Disassembly Ninjutsu book along with old (hard to find) public specs related to BIOS. 

Feel free to clone it.
